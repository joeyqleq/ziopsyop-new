
  # Create bootloader animation

  This is a code bundle for Create bootloader animation. The original project is available at https://www.figma.com/design/sIQ1DNjdFWTYrjb5ShhUc7/Create-bootloader-animation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  