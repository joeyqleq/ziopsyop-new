import { useMemo } from "react";
import { BootConfig, localProgress } from "./bootConfig";
import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { buildMediaField } from "./ascii/sceneFields";
import { useGridSize } from "./ascii/useGrid";
import { DataRow, Question, SceneLabels, Sub, Title } from "./SceneLabels";

const SCAN_TAGS = ["EMPHASIS", "OMISSION", "TIMING", "ATTRIBUTION"];

/** Part III — THE MANUFACTURED REALITY. One IDF strike, three framings. */
export function AsciiMediaScene({
  progress,
  start,
  end,
  config,
}: {
  progress: number;
  start: number;
  end: number;
  config: BootConfig;
}) {
  const { cols, rows } = useGridSize();
  const lp = localProgress(progress, start, end);
  const field = useMemo(() => buildMediaField(cols, rows), [cols, rows]);
  const reveal = Math.min(1, lp / 0.5);

  return (
    <div className="zio-scene" data-active="true">
      <AsciiField
        field={field}
        reveal={reveal}
        mode="radial-out"
        noiseColor={PALETTE.red}
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
      />
      {/* red scan bars sweeping each third — expose framing */}
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          aria-hidden="true"
          style={{
            position: "absolute",
            left: `${8 + i * 30}%`,
            width: "26%",
            height: 2,
            background: "linear-gradient(90deg, transparent, var(--z-red), transparent)",
            animation: "zio-scan 2.6s linear infinite",
            animationDelay: `${i * 0.5}s`,
            zIndex: 2,
          }}
        />
      ))}
      <SceneLabels>
        <div aria-hidden="true" style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap", marginBottom: 4 }}>
          {SCAN_TAGS.map((t) => (
            <span key={t} style={{ fontSize: 8, letterSpacing: "0.18em", color: "var(--z-red)", border: "1px solid rgba(255,77,94,0.3)", padding: "2px 6px" }}>{t}</span>
          ))}
        </div>
        <Title color="var(--z-red)">III // THE MANUFACTURED REALITY</Title>
        <Sub>MEDIA-WAR FORENSICS — ISRAELI PR</Sub>
        <Question>ONE IDF STRIKE — THREE MANUFACTURED REALITIES</Question>
        <DataRow>
          <span>MEDIA STREAMS: <b style={{ color: "var(--z-muted)" }}>{config.mediaStreamCount}</b></span>
          <span>COMPARISON WINDOW: <b style={{ color: "var(--z-muted)" }}>{config.mediaWindow}</b></span>
        </DataRow>
      </SceneLabels>
    </div>
  );
}
