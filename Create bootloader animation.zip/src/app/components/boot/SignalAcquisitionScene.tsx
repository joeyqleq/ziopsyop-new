import { useMemo } from "react";
import { localProgress } from "./bootConfig";
import { SysLabel, TypedText } from "./BootPrimitives";

const FRAGMENT_CHARS = ". : + / \\ | [ ] { } 0 1 # % @".split(" ");

/** 0.0–2.5s — SIGNAL ACQUISITION. Disordered fragments snap onto a grid. */
export function SignalAcquisitionScene({
  progress,
  start,
  end,
}: {
  progress: number;
  start: number;
  end: number;
}) {
  const lp = localProgress(progress, start, end);

  const fragments = useMemo(
    () =>
      Array.from({ length: 40 }, (_, i) => ({
        ch: FRAGMENT_CHARS[i % FRAGMENT_CHARS.length],
        chaosX: Math.random() * 100,
        chaosY: Math.random() * 100,
        gridX: (i % 10) * 10 + 5,
        gridY: Math.floor(i / 10) * 22 + 20,
        dx: `${(Math.random() - 0.5) * 40}px`,
        dy: `${(Math.random() - 0.5) * 40}px`,
      })),
    []
  );

  // As lp -> 1, fragments interpolate from chaos toward the invisible grid.
  const snap = Math.max(0, (lp - 0.4) / 0.6);

  return (
    <div className="zio-scene" data-active="true">
      <div aria-hidden="true" style={{ position: "absolute", inset: 0 }}>
        {fragments.map((f, i) => {
          const x = f.chaosX + (f.gridX - f.chaosX) * snap;
          const y = f.chaosY + (f.gridY - f.chaosY) * snap;
          return (
            <span
              key={i}
              style={{
                position: "absolute",
                left: `${x}%`,
                top: `${y}%`,
                fontSize: 12,
                color: i % 3 === 0 ? "var(--z-mint)" : "var(--z-tertiary)",
                opacity: 0.1 + snap * 0.4,
                transition: "opacity 0.3s ease",
                // @ts-expect-error CSS custom props
                "--dx": f.dx,
                "--dy": f.dy,
                animation: snap < 0.2 ? "zio-drift 3s ease-in-out infinite" : "none",
              }}
            >
              {f.ch}
            </span>
          );
        })}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "center", zIndex: 2, textAlign: "center" }}>
        <SysLabel color="var(--z-text)" style={{ letterSpacing: "0.3em", fontSize: 12 }}>
          <TypedText
            text="ZIOPSYOP // OPEN-SOURCE COUNTER-PSYOP SYSTEM"
            progress={progress}
            start={start}
            end={start + (end - start) * 0.5}
            caret
          />
        </SysLabel>
        <SysLabel style={{ letterSpacing: "0.24em" }}>
          <TypedText
            text="EXPOSING & DEBUNKING ISRAEL'S ONLINE PSYOPS…"
            progress={progress}
            start={start + (end - start) * 0.45}
            end={end}
            caret
          />
        </SysLabel>
      </div>
    </div>
  );
}
