import { useEffect, useState } from "react";
import { Cell, Field, RGB, rampChar } from "./asciiCore";

export interface AsciifyOpts {
  /** cells whose source coverage is below this are treated as empty */
  alphaThreshold?: number;
  /** luminance gain applied before ramp lookup */
  gain?: number;
  /** floor added to luminance so faint areas still get a light glyph */
  floor?: number;
  /** override the sampled colour with a fixed tint */
  tint?: RGB;
  /** multiply sampled colour toward its own saturated version */
  saturate?: number;
}

/** Rasterize an image data URL to an ASCII Field of cols×rows using source colour. */
export function imageToField(
  img: HTMLImageElement,
  cols: number,
  rows: number,
  opts: AsciifyOpts = {}
): Field {
  const { alphaThreshold = 0.28, gain = 1.15, floor = 0.12, tint, saturate = 1.25 } = opts;

  const canvas = document.createElement("canvas");
  canvas.width = cols;
  canvas.height = rows;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  // "contain" fit, compensating for ~2:1 tall character cells (rows count as 0.5 tall).
  const iw = img.naturalWidth || img.width;
  const ih = img.naturalHeight || img.height;
  const scale = Math.min(cols / iw, rows / (ih * 0.5));
  const dw = iw * scale;
  const dh = ih * scale * 0.5;
  const ox = (cols - dw) / 2;
  const oy = (rows - dh) / 2;
  ctx.clearRect(0, 0, cols, rows);
  ctx.drawImage(img, ox, oy, dw, dh);

  const data = ctx.getImageData(0, 0, cols, rows).data;
  const field: Field = [];
  for (let y = 0; y < rows; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < cols; x++) {
      const i = (y * cols + x) * 4;
      let r = data[i], g = data[i + 1], b = data[i + 2];
      const a = data[i + 3] / 255;
      if (a < alphaThreshold) {
        row.push({ ch: " ", color: [0, 0, 0], a: 0 });
        continue;
      }
      let lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      lum = Math.min(1, lum * gain + floor);

      let color: RGB = tint ?? [r, g, b];
      if (!tint && saturate !== 1) {
        const avg = (r + g + b) / 3;
        color = [
          Math.min(255, avg + (r - avg) * saturate),
          Math.min(255, avg + (g - avg) * saturate),
          Math.min(255, avg + (b - avg) * saturate),
        ];
      }
      row.push({ ch: rampChar(lum), color, a: Math.min(1, a * 1.1), glow: lum > 0.7 ? 0.6 : 0 });
    }
    field.push(row);
  }
  return field;
}

const imageCache = new Map<string, Promise<HTMLImageElement>>();

function loadImage(src: string): Promise<HTMLImageElement> {
  let p = imageCache.get(src);
  if (!p) {
    p = new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
    imageCache.set(src, p);
  }
  return p;
}

/** React hook: returns an ASCII Field for an image once it has rasterized. */
export function useAsciiImage(
  src: string,
  cols: number,
  rows: number,
  opts?: AsciifyOpts
): Field | null {
  const [field, setField] = useState<Field | null>(null);
  useEffect(() => {
    let alive = true;
    loadImage(src)
      .then((img) => {
        if (alive) setField(imageToField(img, cols, rows, opts));
      })
      .catch(() => {
        if (alive) setField(null);
      });
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src, cols, rows]);
  return field;
}
