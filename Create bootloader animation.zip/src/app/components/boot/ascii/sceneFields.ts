import { Field, Grid, PALETTE, RGB } from "./asciiCore";

function rand(seed: number) {
  // deterministic pseudo-random so fields are stable across renders
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}

/** PART I — reply/bot network. Coordinated speech bubbles imply engineered consent. */
export function buildNetworkField(cols: number, rows: number): Field {
  const g = new Grid(cols, rows);
  const rng = rand(11);
  const mint = PALETTE.mint;
  const dim = PALETTE.mintDim;
  const vio = PALETTE.violet;

  const nodeCount = Math.max(9, Math.floor(cols / 8));
  const nodes: { x: number; y: number; bot: boolean }[] = [];
  for (let i = 0; i < nodeCount; i++) {
    nodes.push({
      x: 4 + rng() * (cols - 8),
      y: 4 + rng() * (rows - 8),
      bot: rng() > 0.45,
    });
  }

  // edges — bots are densely interconnected (coordination)
  for (let i = 0; i < nodes.length; i++) {
    const links = nodes[i].bot ? 3 : 1;
    for (let k = 0; k < links; k++) {
      const j = Math.floor(rng() * nodes.length);
      if (j === i) continue;
      g.line(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y, "*", dim, 0.45);
    }
  }

  // nodes
  for (const n of nodes) {
    const col = n.bot ? mint : vio;
    g.set(n.x - 1, n.y, "(", col, 0.8);
    g.set(n.x + 1, n.y, ")", col, 0.8);
    g.set(n.x, n.y, "@", col, 1, n.bot ? 0.6 : 0);
    if (n.bot) g.circle(n.x, n.y, 2.2, "o", col, 0.35);
  }

  // coordinated speech bubbles — identical widths & bars = copy-paste messaging
  const bubbleW = 11;
  for (let b = 0; b < Math.min(4, Math.floor(cols / 24)); b++) {
    const bx = 6 + Math.floor(rng() * (cols - bubbleW - 8));
    const by = 3 + Math.floor(rng() * (rows - 6));
    g.box(bx, by, bubbleW, 3, mint, 0.7);
    g.text(bx + 2, by + 1, "───────", mint, 0.55);
    g.set(bx + 2, by + 3, "╲", mint, 0.6); // bubble tail
  }
  return g.field();
}

/** PART I transform beat — the network momentarily forms a "friendly" handshake. */
export function buildHandshakeField(cols: number, rows: number): Field {
  const g = new Grid(cols, rows);
  const mint = PALETTE.mint;
  const cx = cols / 2;
  const cy = rows / 2;
  // two interlocking bracket "hands" meeting at center
  for (let i = 0; i < 10; i++) {
    g.set(cx - 10 + i, cy - 2 + Math.floor(i / 3), "═", mint, 0.7);
    g.set(cx + 10 - i, cy - 2 + Math.floor(i / 3), "═", mint, 0.7);
  }
  g.text(cx - 6, cy, "(@)══╳══(@)", mint, 1, 0.5);
  g.circle(cx, cy, 6, "·", PALETTE.violet, 0.4);
  g.circle(cx, cy, 9, "·", mint, 0.25);
  return g.field();
}

/** PART II — battlefield terrain + layered evidence markers. */
export function buildBattlefieldField(cols: number, rows: number): Field {
  const g = new Grid(cols, rows);
  const rng = rand(29);
  const amber = PALETTE.amber;
  const amberDim: RGB = [150, 118, 52];

  // topographic contours
  for (let c = 0; c < 5; c++) {
    const yBase = 4 + c * ((rows - 8) / 5);
    const amp = 2 + rng() * 3;
    const freq = 0.12 + rng() * 0.08;
    const phase = rng() * 6;
    for (let x = 1; x < cols - 1; x++) {
      const y = yBase + Math.sin(x * freq + phase) * amp;
      const ch = Math.random() > 0.5 ? "·" : "-";
      g.set(x, y, ch, amberDim, 0.35);
      if (x % 9 === 0) g.set(x, y, rng() > 0.5 ? "╱" : "╲", amber, 0.5);
    }
  }
  // coordinate ticks
  for (let x = 6; x < cols - 4; x += 12) {
    g.set(x, 1, "+", amberDim, 0.4);
    g.text(x + 1, 1, `${(30 + Math.floor(rng() * 6))}.${Math.floor(rng() * 9)}N`, amberDim, 0.3);
  }

  // event markers: claimed(◆ solid) / documented(◇ outline) / disputed(▱ dashed)
  const markers = [
    { x: 0.2, y: 0.3, ch: "◆", col: amber, a: 1, tag: "" },
    { x: 0.6, y: 0.25, ch: "◇", col: amberDim, a: 0.8, tag: "" },
    { x: 0.42, y: 0.55, ch: "◆", col: amber, a: 1, tag: "" },
    { x: 0.75, y: 0.62, ch: "▱", col: PALETTE.red, a: 0.9, tag: "DISPUTED" },
    { x: 0.3, y: 0.7, ch: "◇", col: amberDim, a: 0.8, tag: "" },
  ];
  for (const m of markers) {
    const mx = Math.floor(m.x * cols);
    const my = Math.floor(m.y * rows);
    g.set(mx, my, m.ch, m.col, m.a, m.col === amber ? 0.5 : 0);
    // crosshair ticks
    g.set(mx - 2, my, "-", m.col, 0.4);
    g.set(mx + 2, my, "-", m.col, 0.4);
    if (m.tag) g.text(mx - 3, my + 1, m.tag, PALETTE.red, 0.7);
  }
  return g.field();
}

/** PART III — three broadcast panes, one event framed three different ways. */
export function buildMediaField(cols: number, rows: number): Field {
  const g = new Grid(cols, rows);
  const red = PALETTE.red;
  const redDim: RGB = [150, 50, 60];
  const paneW = Math.floor((cols - 8) / 3);
  const paneH = rows - 6;
  const y0 = 3;
  const waves = ["▁▃▅█▇▅▃▁▁▁", "▁▂▃▄▅▄▃▂▁▁", "█▇▆▄▂▁▁▂▄▆"];
  const emph = ["EMPHASIS", "TIMING", "OMISSION"];
  const src = ["IL DOMESTIC", "INTL FEED", "FIELD SOURCE"];

  for (let i = 0; i < 3; i++) {
    const x = 3 + i * (paneW + 1);
    g.box(x, y0, paneW, paneH, redDim, 0.7);
    g.text(x + 2, y0 + 1, src[i].slice(0, paneW - 4), PALETTE.muted, 0.8);
    // same central event enters every pane
    g.text(x + 2, y0 + 3, "◆ EVENT-0", red, 0.9, 0.4);
    // divergent headline waveform
    const wf = waves[i];
    g.text(x + 2, y0 + 5, wf.slice(0, paneW - 4), PALETTE.amber, 0.85);
    // omission block (different per pane)
    const omit = "░".repeat(2 + i * 2);
    g.text(x + 2, y0 + 7, `HEADLINE ${omit}`, PALETTE.tertiary, 0.6);
    g.text(x + 2, paneH + y0 - 2, emph[i], red, 0.8);
  }
  return g.field();
}
