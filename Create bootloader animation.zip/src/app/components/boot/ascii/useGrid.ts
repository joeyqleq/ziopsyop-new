import { useEffect, useState } from "react";

/** Fewer ASCII columns / particles on small screens. */
export function useGridSize() {
  const get = () => {
    const w = typeof window !== "undefined" ? window.innerWidth : 1200;
    if (w < 640) return { cols: 54, rows: 30, mobile: true };
    if (w < 1024) return { cols: 84, rows: 38, mobile: false };
    return { cols: 104, rows: 46, mobile: false };
  };
  const [size, setSize] = useState(get);
  useEffect(() => {
    const on = () => setSize(get());
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  return size;
}
