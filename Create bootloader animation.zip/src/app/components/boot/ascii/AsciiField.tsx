import { CSSProperties, useEffect, useRef } from "react";
import { Field, RAMP, RGB, rgba } from "./asciiCore";

export type RevealMode = "radial-in" | "radial-out" | "scan" | "random" | "none";

export interface AsciiFieldProps {
  field: Field | null;
  /** 0..1 how much of the field has resolved from noise */
  reveal: number;
  /** overall opacity multiplier (use to fade a scene in/out) */
  intensity?: number;
  mode?: RevealMode;
  /** colour of the pre-reveal noise characters */
  noiseColor?: RGB;
  /** enable subtle per-cell shimmer + rare glyph corruption */
  shimmer?: boolean;
  /** pause the RAF loop (also auto-pauses when tab hidden) */
  playing?: boolean;
  glow?: boolean;
  className?: string;
  style?: CSSProperties;
}

const NOISE = "01#%@·:+/\\|[]{}=-*";

export function AsciiField({
  field,
  reveal,
  intensity = 1,
  mode = "radial-in",
  noiseColor = [62, 230, 193],
  shimmer = true,
  playing = true,
  glow = true,
  className,
  style,
}: AsciiFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const props = useRef({ field, reveal, intensity, mode, noiseColor, shimmer, playing, glow });
  props.current = { field, reveal, intensity, mode, noiseColor, shimmer, playing, glow };

  // Per-cell reveal thresholds, recomputed when the field identity changes.
  const thresholdsRef = useRef<number[][] | null>(null);
  useEffect(() => {
    if (!field) {
      thresholdsRef.current = null;
      return;
    }
    const rows = field.length;
    const cols = field[0]?.length ?? 0;
    const cx = cols / 2;
    const cy = rows / 2;
    const maxD = Math.hypot(cx, cy) || 1;
    const th: number[][] = [];
    for (let y = 0; y < rows; y++) {
      const r: number[] = [];
      for (let x = 0; x < cols; x++) {
        const d = Math.hypot(x - cx, y - cy) / maxD; // 0 center .. 1 edge
        let base: number;
        switch (props.current.mode) {
          case "radial-out": base = d; break;
          case "radial-in": base = 1 - d; break;
          case "scan": base = y / rows; break;
          default: base = Math.random();
        }
        r.push(Math.min(0.98, Math.max(0.02, base * 0.8 + Math.random() * 0.2)));
      }
      th.push(r);
    }
    thresholdsRef.current = th;
  }, [field]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
    let raf = 0;
    let w = 0;
    let h = 0;

    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const draw = (ts: number) => {
      raf = requestAnimationFrame(draw);
      const p = props.current;
      if (!p.playing || document.hidden) return;
      ctx.clearRect(0, 0, w, h);
      const f = p.field;
      const th = thresholdsRef.current;
      if (!f || !th || f.length === 0) return;

      const rows = f.length;
      const cols = f[0].length;
      // contain-fit the grid; character cells are ~2:1 tall.
      const cellW = Math.min(w / cols, h / (rows * 1.0));
      const cellH = cellW;
      const gridW = cellW * cols;
      const gridH = cellH * rows;
      const ox = (w - gridW) / 2;
      const oy = (h - gridH) / 2;
      const fontPx = cellH * 1.02;

      ctx.font = `${fontPx}px "JetBrains Mono", ui-monospace, monospace`;
      ctx.textBaseline = "top";
      ctx.textAlign = "left";

      const t = ts / 1000;
      const reveal = p.reveal;
      const noise = p.noiseColor;

      for (let y = 0; y < rows; y++) {
        const py = oy + y * cellH;
        for (let x = 0; x < cols; x++) {
          const cell = f[y][x];
          const thr = th[y][x];
          const px = ox + x * cellW;

          if (reveal >= thr) {
            if (cell.a <= 0) continue;
            let alpha = cell.a * p.intensity;
            let ch = cell.ch;
            if (ch === " ") continue;
            if (p.shimmer) {
              // gentle breathing + very rare one-frame corruption
              alpha *= 0.82 + 0.18 * Math.sin(t * 2 + (x + y) * 0.6);
              if (Math.random() < 0.0015) ch = RAMP[(Math.random() * RAMP.length) | 0];
            }
            if (p.glow && cell.glow) {
              ctx.shadowColor = rgba(cell.color, 0.9);
              ctx.shadowBlur = cell.glow * 6;
            } else {
              ctx.shadowBlur = 0;
            }
            ctx.fillStyle = rgba(cell.color, alpha);
            ctx.fillText(ch, px, py);
          } else if (cell.a > 0 && reveal > thr - 0.14) {
            // edge-of-reveal noise: flicker a faint glyph as it "resolves"
            ctx.shadowBlur = 0;
            const flick = Math.random();
            if (flick < 0.5) {
              const na = 0.10 + 0.22 * flick;
              ctx.fillStyle = rgba(noise, na * p.intensity);
              ctx.fillText(NOISE[(Math.random() * NOISE.length) | 0], px, py);
            }
          }
        }
      }
      ctx.shadowBlur = 0;
    };

    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return <canvas ref={canvasRef} className={className} style={style} aria-hidden="true" />;
}
