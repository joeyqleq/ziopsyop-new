/**
 * Core ASCII types + a mutable drawing grid with primitives.
 * A "field" is a 2D array of cells; scenes build fields, the renderer paints them.
 */

export type RGB = [number, number, number];

export interface Cell {
  ch: string;
  color: RGB;
  /** target alpha 0..1 */
  a: number;
  /** optional additive glow strength 0..1 */
  glow?: number;
}

export const PALETTE = {
  bg: [6, 6, 8] as RGB,
  text: [232, 234, 233] as RGB,
  muted: [138, 143, 152] as RGB,
  tertiary: [86, 91, 100] as RGB,
  mint: [62, 230, 193] as RGB,
  mintDim: [40, 150, 128] as RGB,
  red: [255, 77, 94] as RGB,
  amber: [232, 180, 76] as RGB,
  blue: [78, 168, 255] as RGB,
  yellow: [255, 210, 63] as RGB,
  violet: [123, 57, 208] as RGB,
  green: [182, 255, 124] as RGB,
};

/** Dark → bright density ramp (space = empty). */
export const RAMP = " .·-:=+ioO0%#8@█";

export function rampChar(lum: number): string {
  const i = Math.max(0, Math.min(RAMP.length - 1, Math.round(lum * (RAMP.length - 1))));
  return RAMP[i];
}

export function mix(a: RGB, b: RGB, t: number): RGB {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
}

export function rgba(c: RGB, a: number): string {
  return `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
}

export type Field = Cell[][];

/** Mutable grid with a small drawing API; call .field() to snapshot. */
export class Grid {
  cols: number;
  rows: number;
  cells: Field;

  constructor(cols: number, rows: number) {
    this.cols = cols;
    this.rows = rows;
    this.cells = Array.from({ length: rows }, () =>
      Array.from({ length: cols }, () => ({ ch: " ", color: PALETTE.tertiary, a: 0 }))
    );
  }

  in(x: number, y: number) {
    return x >= 0 && x < this.cols && y >= 0 && y < this.rows;
  }

  set(x: number, y: number, ch: string, color: RGB, a = 1, glow = 0) {
    x = Math.round(x);
    y = Math.round(y);
    if (!this.in(x, y)) return;
    this.cells[y][x] = { ch, color, a, glow };
  }

  text(x: number, y: number, str: string, color: RGB, a = 1, glow = 0) {
    for (let i = 0; i < str.length; i++) this.set(x + i, y, str[i], color, a, glow);
  }

  /** Center a single-line string on row y. */
  textCenter(y: number, str: string, color: RGB, a = 1, glow = 0) {
    this.text(Math.round((this.cols - str.length) / 2), y, str, color, a, glow);
  }

  hline(x0: number, x1: number, y: number, ch: string, color: RGB, a = 1) {
    const [lo, hi] = x0 < x1 ? [x0, x1] : [x1, x0];
    for (let x = lo; x <= hi; x++) this.set(x, y, ch, color, a);
  }

  vline(x: number, y0: number, y1: number, ch: string, color: RGB, a = 1) {
    const [lo, hi] = y0 < y1 ? [y0, y1] : [y1, y0];
    for (let y = lo; y <= hi; y++) this.set(x, y, ch, color, a);
  }

  /** Thin box using unicode box-drawing chars. */
  box(x: number, y: number, w: number, h: number, color: RGB, a = 1) {
    const x1 = x + w - 1;
    const y1 = y + h - 1;
    this.set(x, y, "┌", color, a);
    this.set(x1, y, "┐", color, a);
    this.set(x, y1, "└", color, a);
    this.set(x1, y1, "┘", color, a);
    for (let i = x + 1; i < x1; i++) {
      this.set(i, y, "─", color, a);
      this.set(i, y1, "─", color, a);
    }
    for (let j = y + 1; j < y1; j++) {
      this.set(x, j, "│", color, a);
      this.set(x1, j, "│", color, a);
    }
  }

  line(x0: number, y0: number, x1: number, y1: number, ch: string, color: RGB, a = 1) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx - dy;
    for (;;) {
      // choose a directional slash for diagonals
      let c = ch;
      if (ch === "*") {
        if (dx > dy * 2) c = "─";
        else if (dy > dx * 2) c = "│";
        else c = (sx === sy ? "╲" : "╱");
      }
      this.set(x0, y0, c, color, a);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 > -dy) { err -= dy; x0 += sx; }
      if (e2 < dx) { err += dx; y0 += sy; }
    }
  }

  circle(cx: number, cy: number, r: number, ch: string, color: RGB, a = 1, aspect = 0.5) {
    // aspect compensates for tall character cells (chars are ~2x tall vs wide)
    for (let deg = 0; deg < 360; deg += 4) {
      const rad = (deg * Math.PI) / 180;
      const x = cx + Math.cos(rad) * r;
      const y = cy + Math.sin(rad) * r * aspect;
      this.set(x, y, ch, color, a);
    }
  }

  field(): Field {
    return this.cells;
  }
}
