// Raw SVG source of the ZioPSYOP eye logo, turned into a data URL.
// Using ?raw + a data URL avoids asset-resolution issues (the previous <img>
// with a bundler URL rendered as a broken image) and lets us rasterize the
// logo to a canvas for high-fidelity image-to-ASCII conversion.
import eyeSvgRaw from "../../../../imports/eye_logo_1.svg?raw";

export const EYE_SVG_RAW: string = eyeSvgRaw;

export const EYE_SVG_DATA_URL = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(eyeSvgRaw)}`;
