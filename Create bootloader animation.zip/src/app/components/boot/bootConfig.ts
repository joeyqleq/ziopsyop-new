/**
 * ZioPSYOP boot sequence — shared configuration, tokens and phase timeline.
 *
 * All evidence values are configurable props. Estimated / unavailable values
 * must be visibly labelled by the consuming scene, never silently faked.
 */

export interface BootConfig {
  /** Total overlay duration in ms. Storyboard is authored against 30000ms. */
  duration: number;
  /** Delay before the SKIP control appears, in ms. */
  skipDelay: number;

  // ---- Replaceable evidence props (Part I) ----
  artifactCount: string;
  observationWindow: string;

  // ---- Replaceable evidence props (Part II) ----
  documentedEventCount: string;
  sourceStreamCount: string;
  lastUpdated: string;

  // ---- Replaceable evidence props (Part III) ----
  mediaStreamCount: string;
  mediaWindow: string;
}

export const DEFAULT_BOOT_CONFIG: BootConfig = {
  duration: 30000,
  skipDelay: 2000,
  artifactCount: "UNAVAILABLE",
  observationWindow: "UNAVAILABLE",
  documentedEventCount: "UNAVAILABLE",
  sourceStreamCount: "5",
  lastUpdated: "UNAVAILABLE",
  mediaStreamCount: "3",
  mediaWindow: "UNAVAILABLE",
};

/** Classified-dossier colour system. Kept in one place; referenced everywhere. */
export const BOOT_TOKENS = {
  bg: "#060608",
  panel: "#0A0A0E",
  raised: "#101016",
  text: "#E8EAE9",
  muted: "#8A8F98",
  tertiary: "#565B64",
  mint: "#3EE6C1",
  red: "#FF4D5E",
  amber: "#E8B44C",
  glitchBlue: "#4EA8FF",
  glitchYellow: "#FFD23F",
  violet: "#7B39D0",
} as const;

export interface BootPhase {
  index: number;
  /** Fractional start / end of the total duration [0..1]. */
  start: number;
  end: number;
  /** Rail id, e.g. "01 / 06". */
  id: string;
  label: string;
}

/** The six labelled phases, authored as fractions of the total duration. */
export const BOOT_PHASES: BootPhase[] = [
  { index: 0, start: 0.0, end: 2.5 / 30, id: "01 / 06", label: "ACQUIRE" },
  { index: 1, start: 2.5 / 30, end: 7.5 / 30, id: "02 / 06", label: "MAP THE NARRATIVE" },
  { index: 2, start: 7.5 / 30, end: 13.0 / 30, id: "03 / 06", label: "RECONCILE THE BATTLEFIELD" },
  { index: 3, start: 13.0 / 30, end: 18.5 / 30, id: "04 / 06", label: "COMPARE THE FRAMES" },
  { index: 4, start: 18.5 / 30, end: 24.0 / 30, id: "05 / 06", label: "CORRELATE THE SYSTEM" },
  { index: 5, start: 24.0 / 30, end: 1.0, id: "06 / 06", label: "DECLASSIFY" },
];

export const SR_DESCRIPTION =
  "ZioPSYOP: an open-source investigation exposing and debunking the most widespread Israeli and IDF psychological operations online. Coordinated subreddit narratives, battlefield records, and media framing are reconstructed as one evidence system.";

/** Returns the active phase for a given progress fraction [0..1]. */
export function phaseFor(progress: number): BootPhase {
  for (const p of BOOT_PHASES) {
    if (progress < p.end) return p;
  }
  return BOOT_PHASES[BOOT_PHASES.length - 1];
}

/** Local, eased [0..1] progress within a scene's [start,end] window. */
export function localProgress(progress: number, start: number, end: number): number {
  if (progress <= start) return 0;
  if (progress >= end) return 1;
  return (progress - start) / (end - start);
}
