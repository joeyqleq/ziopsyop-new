import { useEffect, useRef, useState } from "react";

/**
 * Drives a single RAF-based [0..1] progress value over `duration` ms.
 * - Pauses (freezes elapsed) while the tab is hidden.
 * - Cleans up the RAF loop and listeners on unmount (Strict-Mode safe).
 * - Calls `onComplete` exactly once when progress reaches 1.
 */
export function useBootTimeline(
  duration: number,
  active: boolean,
  onComplete: () => void
) {
  const [progress, setProgress] = useState(0);
  const rafRef = useRef<number | null>(null);
  const elapsedRef = useRef(0);
  const lastTsRef = useRef<number | null>(null);
  const doneRef = useRef(false);
  const seekRef = useRef<(fraction: number) => void>(() => {});
  const completeRef = useRef(onComplete);
  completeRef.current = onComplete;

  useEffect(() => {
    if (!active) return;
    doneRef.current = false;
    elapsedRef.current = 0;
    lastTsRef.current = null;

    const tick = (ts: number) => {
      if (document.hidden) {
        // Freeze: drop the reference frame so we don't jump on resume.
        lastTsRef.current = null;
        rafRef.current = requestAnimationFrame(tick);
        return;
      }
      if (lastTsRef.current == null) lastTsRef.current = ts;
      const dt = ts - lastTsRef.current;
      lastTsRef.current = ts;
      elapsedRef.current += dt;

      const p = Math.min(1, elapsedRef.current / duration);
      setProgress(p);

      if (p >= 1) {
        if (!doneRef.current) {
          doneRef.current = true;
          completeRef.current();
        }
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };

    seekRef.current = (fraction: number) => {
      doneRef.current = false;
      elapsedRef.current = Math.max(0, Math.min(1, fraction)) * duration;
      lastTsRef.current = null;
      setProgress(Math.max(0, Math.min(1, fraction)));
    };

    rafRef.current = requestAnimationFrame(tick);

    const onVisibility = () => {
      lastTsRef.current = null;
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [duration, active]);

  const seek = (fraction: number) => seekRef.current(fraction);
  return { progress, seek };
}
