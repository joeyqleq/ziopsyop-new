import { useMemo } from "react";
import { BootConfig, localProgress } from "./bootConfig";
import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { buildNetworkField, buildHandshakeField } from "./ascii/sceneFields";
import { useGridSize } from "./ascii/useGrid";
import { DataRow, Question, SceneLabels, Sub, Title } from "./SceneLabels";

/** Part I — THE MANUFACTURED FRIEND. Reply/hasbara network → handshake → network. */
export function AsciiNetworkScene({
  progress,
  start,
  end,
  config,
}: {
  progress: number;
  start: number;
  end: number;
  config: BootConfig;
}) {
  const { cols, rows } = useGridSize();
  const lp = localProgress(progress, start, end);

  const network = useMemo(() => buildNetworkField(cols, rows), [cols, rows]);
  const handshake = useMemo(() => buildHandshakeField(cols, rows), [cols, rows]);

  // Transformation beat: network → handshake (0.45–0.65) → back to network.
  const showHandshake = lp > 0.45 && lp < 0.66;
  const field = showHandshake ? handshake : network;
  const reveal = showHandshake
    ? Math.min(1, (lp - 0.45) / 0.1)
    : lp < 0.45
    ? Math.min(1, lp / 0.4)
    : 1;

  return (
    <div className="zio-scene" data-active="true">
      <AsciiField
        field={field}
        reveal={reveal}
        mode="random"
        noiseColor={PALETTE.mint}
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
      />
      <SceneLabels>
        <Title color="var(--z-mint)">I // THE MANUFACTURED FRIEND</Title>
        <Sub>NARRATIVE FORENSICS — HASBARA ASTROTURF</Sub>
        <Question>ORGANIC VOICES — OR AN ENGINEERED PRO-ISRAEL CONSENSUS?</Question>
        <DataRow>
          <span>ACCOUNTS MAPPED: <b style={{ color: "var(--z-muted)" }}>{config.artifactCount}</b></span>
          <span>OBSERVATION WINDOW: <b style={{ color: "var(--z-muted)" }}>{config.observationWindow}</b></span>
          <span>SOURCE: PUBLIC ARCHIVE</span>
        </DataRow>
      </SceneLabels>
    </div>
  );
}
