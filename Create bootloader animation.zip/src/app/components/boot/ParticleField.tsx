import { useEffect, useRef } from "react";
import { BOOT_TOKENS } from "./bootConfig";

interface ParticleFieldProps {
  /** When false, the RAF loop stops (used for reduced-motion / inactive). */
  active: boolean;
  /** Desktop-only pointer deflection. */
  interactive?: boolean;
}

interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  c: string;
  a: number;
}

/**
 * Sparse mint / violet signal particles on black. One lightweight canvas.
 * Caps devicePixelRatio and particle density; pauses when the tab is hidden.
 */
export function ParticleField({ active, interactive = true }: ParticleFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointerRef = useRef<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    let width = 0;
    let height = 0;
    let particles: P[] = [];
    let raf = 0;

    const isMobile = () => window.innerWidth < 640;

    const build = () => {
      width = canvas.clientWidth;
      height = canvas.clientHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const density = isMobile() ? 0.00006 : 0.00011;
      const count = Math.max(24, Math.floor(width * height * density));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.15,
        vy: (Math.random() - 0.5) * 0.15,
        r: Math.random() * 1.4 + 0.4,
        c: Math.random() > 0.5 ? BOOT_TOKENS.mint : BOOT_TOKENS.violet,
        a: Math.random() * 0.5 + 0.1,
      }));
    };

    const draw = () => {
      if (document.hidden) {
        raf = requestAnimationFrame(draw);
        return;
      }
      ctx.clearRect(0, 0, width, height);
      const ptr = pointerRef.current;
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        if (ptr && interactive && !isMobile()) {
          const dx = p.x - ptr.x;
          const dy = p.y - ptr.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < 9000 && d2 > 0.01) {
            const f = (9000 - d2) / 9000;
            const d = Math.sqrt(d2);
            p.x += (dx / d) * f * 1.6;
            p.y += (dy / d) * f * 1.6;
          }
        }

        ctx.globalAlpha = p.a;
        ctx.fillStyle = p.c;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(draw);
    };

    build();
    if (active) raf = requestAnimationFrame(draw);

    const onResize = () => build();
    const onPointer = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      pointerRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onLeave = () => {
      pointerRef.current = null;
    };

    window.addEventListener("resize", onResize);
    if (interactive) {
      window.addEventListener("pointermove", onPointer);
      window.addEventListener("pointerleave", onLeave);
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onPointer);
      window.removeEventListener("pointerleave", onLeave);
    };
  }, [active, interactive]);

  return <canvas ref={canvasRef} className="zio-boot__particles" aria-hidden="true" />;
}
