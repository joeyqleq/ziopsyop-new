import { BOOT_PHASES, phaseFor } from "./bootConfig";

/**
 * Six labelled phase segments (not a generic spinner). In preview mode a phase
 * marker is clickable to scrub; production behaviour is strictly linear.
 */
export function BootProgressRail({
  progress,
  onSeek,
}: {
  progress: number;
  onSeek?: (fraction: number) => void;
}) {
  const active = phaseFor(progress);
  return (
    <div className="zio-rail" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress * 100)}>
      {BOOT_PHASES.map((p) => {
        const isPast = progress >= p.end;
        const isActive = p.index === active.index;
        const fill = isPast ? 1 : isActive ? (progress - p.start) / (p.end - p.start) : 0;
        return (
          <button
            key={p.id}
            type="button"
            disabled={!onSeek}
            onClick={onSeek ? () => onSeek(p.start + 0.001) : undefined}
            aria-hidden="true"
            style={{
              flex: 1,
              textAlign: "left",
              background: "transparent",
              border: "none",
              padding: 0,
              cursor: onSeek ? "pointer" : "default",
            }}
          >
            <div style={{ height: 2, background: "rgba(232,234,233,0.12)", position: "relative", overflow: "hidden" }}>
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  transformOrigin: "left",
                  transform: `scaleX(${fill})`,
                  background: isActive ? "var(--z-mint)" : "rgba(232,234,233,0.45)",
                  transition: "transform 0.1s linear",
                }}
              />
            </div>
            <div
              style={{
                marginTop: 6,
                fontSize: 8,
                letterSpacing: "0.14em",
                color: isActive ? "var(--z-mint)" : isPast ? "var(--z-muted)" : "var(--z-tertiary)",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {p.id} — {p.label}
            </div>
          </button>
        );
      })}
    </div>
  );
}
