import { localProgress } from "./bootConfig";
import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { useAsciiImage } from "./ascii/asciify";
import { EYE_SVG_DATA_URL } from "./ascii/eyeLogo";
import { useGridSize } from "./ascii/useGrid";
import { Sub } from "./SceneLabels";

const ORBIT = ["WHO SPOKE?", "WHAT HAPPENED?", "HOW WAS IT FRAMED?"];

/** Convergence — the three fronts resolve into the asciified ZioPSYOP eye. */
export function AsciiEyeConvergence({
  progress,
  start,
  end,
  pointer,
}: {
  progress: number;
  start: number;
  end: number;
  pointer: { x: number; y: number } | null;
}) {
  const { cols, rows, mobile } = useGridSize();
  const eye = useAsciiImage(EYE_SVG_DATA_URL, cols, mobile ? 26 : 34, {
    gain: 1.3,
    floor: 0.14,
    saturate: 1.4,
  });
  const lp = localProgress(progress, start, end);
  const reveal = Math.min(1, lp / 0.55);
  const lockEquation = lp > 0.62;

  // strictly-limited iris tracking
  const dx = pointer ? Math.max(-10, Math.min(10, (pointer.x - 0.5) * 20)) : 0;
  const dy = pointer ? Math.max(-6, Math.min(6, (pointer.y - 0.5) * 12)) : 0;

  return (
    <div className="zio-scene" data-active="true">
      <div
        style={{
          position: "absolute",
          inset: 0,
          transform: `translate(${dx}px, ${dy}px)`,
          transition: "transform 0.5s ease",
        }}
      >
        <AsciiField
          field={eye}
          reveal={reveal}
          mode="radial-in"
          noiseColor={PALETTE.mint}
          glow
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
        />
      </div>

      {/* rotating classification ring */}
      <span
        aria-hidden="true"
        style={{
          position: "absolute",
          left: "50%",
          top: "46%",
          width: mobile ? 150 : 220,
          height: mobile ? 150 : 220,
          transform: "translate(-50%,-50%)",
          borderRadius: "50%",
          border: "1px dashed rgba(62,230,193,0.25)",
          animation: "zio-spin 9s linear infinite",
          opacity: reveal,
        }}
      />

      {/* orbiting questions collapse into the thesis */}
      {ORBIT.map((l, i) => {
        const angle = (i / ORBIT.length) * Math.PI * 2 + lp * Math.PI * 1.2;
        const r = mobile ? 120 : 190;
        return (
          <span
            key={l}
            aria-hidden="true"
            style={{
              position: "absolute",
              left: `calc(50% + ${Math.cos(angle) * r}px)`,
              top: `calc(46% + ${Math.sin(angle) * r * 0.42}px)`,
              transform: "translate(-50%,-50%)",
              fontFamily: '"JetBrains Mono", monospace',
              fontSize: 9,
              letterSpacing: "0.16em",
              color: "var(--z-muted)",
              whiteSpace: "nowrap",
              opacity: lockEquation ? 0 : 0.85 * reveal,
              transition: "opacity 0.5s ease",
            }}
          >
            {l}
          </span>
        );
      })}

      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: "10%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 8,
          padding: "0 20px",
          textAlign: "center",
        }}
      >
        <Sub>CORRELATE THE SYSTEM</Sub>
        <span
          aria-hidden="true"
          style={{
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: "clamp(13px, 2vw, 18px)",
            letterSpacing: "0.16em",
            opacity: lockEquation ? 1 : 0,
            transform: lockEquation ? "scale(1)" : "scale(0.92)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
          }}
        >
          NARRATIVE <span style={{ color: "var(--z-mint)" }}>+</span> FORCE{" "}
          <span style={{ color: "var(--z-amber)" }}>+</span> FRAME{" "}
          <span style={{ color: "var(--z-red)" }}>=</span> MANUFACTURED CONSENT
        </span>
        <span className="zio-prose" aria-hidden="true" style={{ fontSize: 10, color: "var(--z-tertiary)" }}>
          how atrocity is made to look acceptable — thesis, not a numerical result
        </span>
      </div>
    </div>
  );
}
