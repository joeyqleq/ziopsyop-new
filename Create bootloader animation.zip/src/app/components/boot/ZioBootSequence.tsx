import { useEffect, useRef, useState } from "react";
import "./boot.css";
import {
  BootConfig,
  DEFAULT_BOOT_CONFIG,
  SR_DESCRIPTION,
} from "./bootConfig";
import { useBootTimeline } from "./useBootTimeline";
import { ParticleField } from "./ParticleField";
import { BootProgressRail } from "./BootProgressRail";
import { SignalAcquisitionScene } from "./SignalAcquisitionScene";
import { AsciiNetworkScene } from "./AsciiNetworkScene";
import { AsciiBattlefieldScene } from "./AsciiBattlefieldScene";
import { AsciiMediaScene } from "./AsciiMediaScene";
import { AsciiEyeConvergence } from "./AsciiEyeConvergence";
import { WordmarkFinale } from "./WordmarkFinale";
import { ReducedMotionStatic } from "./ReducedMotionStatic";

export interface ZioBootSequenceProps {
  config?: Partial<BootConfig>;
  onComplete: () => void;
  /** Enables clickable phase scrubbing and disables the once-per-session guard upstream. */
  forcePreview?: boolean;
}

// Scene windows as fractions of the total duration (authored against 30s).
const W = {
  acquire: [0.0, 2.5 / 30] as const,
  network: [2.5 / 30, 7.5 / 30] as const,
  battlefield: [7.5 / 30, 13.0 / 30] as const,
  media: [13.0 / 30, 18.5 / 30] as const,
  eye: [18.5 / 30, 24.0 / 30] as const,
  wordmark: [24.0 / 30, 1.0] as const,
};

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const on = () => setReduced(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return reduced;
}

export function ZioBootSequence({ config, onComplete, forcePreview = false }: ZioBootSequenceProps) {
  const cfg: BootConfig = { ...DEFAULT_BOOT_CONFIG, ...config };
  const reducedMotion = usePrefersReducedMotion();

  const [showSkip, setShowSkip] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const pointerRef = useRef<{ x: number; y: number } | null>(null);
  const [pointer, setPointer] = useState<{ x: number; y: number } | null>(null);
  const focusReturnRef = useRef<HTMLElement | null>(null);

  const { progress, seek } = useBootTimeline(cfg.duration, !reducedMotion && !dismissed, onComplete);

  const finish = () => {
    if (dismissed) return;
    setDismissed(true);
    onComplete();
  };

  // SKIP appears after skipDelay.
  useEffect(() => {
    if (reducedMotion) return;
    const t = window.setTimeout(() => setShowSkip(true), cfg.skipDelay);
    return () => window.clearTimeout(t);
  }, [cfg.skipDelay, reducedMotion]);

  // Body scroll lock while active; restored on every exit path.
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  // Keyboard: Esc / Enter / Space finish safely. Never trap focus.
  useEffect(() => {
    focusReturnRef.current = (document.activeElement as HTMLElement) ?? null;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "Enter" || e.key === " " || e.code === "Space") {
        e.preventDefault();
        finish();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      focusReturnRef.current?.focus?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Pointer tracking (normalized) for eye + throttled to RAF via state on move.
  useEffect(() => {
    let raf = 0;
    const onMove = (e: PointerEvent) => {
      pointerRef.current = { x: e.clientX / window.innerWidth, y: e.clientY / window.innerHeight };
    };
    const loop = () => {
      setPointer(pointerRef.current);
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener("pointermove", onMove);
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  if (reducedMotion) {
    return <ReducedMotionStatic onEnter={finish} />;
  }

  // Aperture handoff: black surface becomes transparent from the center outward
  // during the final ~2s (28–30s).
  const handoffLocal = progress > W.wordmark[0] ? (progress - 0.933) / (1 - 0.933) : 0;
  const apertureRadius = handoffLocal > 0 ? `${Math.max(0, 120 - handoffLocal * 130)}%` : "120%";
  const overlayOpacity = handoffLocal > 0.5 ? Math.max(0, 1 - (handoffLocal - 0.5) * 2) : 1;

  const inWindow = (w: readonly [number, number]) => progress >= w[0] && progress < w[1];

  return (
    <div
      className="zio-boot"
      role="dialog"
      aria-label="ZioPSYOP intro sequence"
      style={{ opacity: overlayOpacity }}
    >
      <p className="sr-only">{SR_DESCRIPTION}</p>

      {/* aperture reveal to the homepage behind */}
      <div className="zio-aperture" style={{ ["--ap" as string]: apertureRadius }} aria-hidden="true" />

      {/* corner brackets */}
      <span className="zio-corner zio-corner--tl" aria-hidden="true" style={handoffLocal > 0 ? { opacity: 1 - handoffLocal } : undefined} />
      <span className="zio-corner zio-corner--tr" aria-hidden="true" style={handoffLocal > 0 ? { opacity: 1 - handoffLocal } : undefined} />
      <span className="zio-corner zio-corner--bl" aria-hidden="true" style={handoffLocal > 0 ? { opacity: 1 - handoffLocal } : undefined} />
      <span className="zio-corner zio-corner--br" aria-hidden="true" style={handoffLocal > 0 ? { opacity: 1 - handoffLocal } : undefined} />

      <ParticleField active={!dismissed} />

      {/* top status rail */}
      <div className="zio-toprail" aria-hidden="true">
        <span className="zio-syslabel" style={{ fontSize: 9 }}>ZIOPSYOP // COUNTER-PSYOP SYSTEM</span>
        <span className="zio-syslabel" style={{ fontSize: 9, color: "var(--z-tertiary)" }}>
          T+{(progress * 30).toFixed(1)}s
        </span>
      </div>

      {/* stage */}
      <div className="zio-stage">
        {inWindow(W.acquire) && <SignalAcquisitionScene progress={progress} start={W.acquire[0]} end={W.acquire[1]} />}
        {inWindow(W.network) && <AsciiNetworkScene progress={progress} start={W.network[0]} end={W.network[1]} config={cfg} />}
        {inWindow(W.battlefield) && <AsciiBattlefieldScene progress={progress} start={W.battlefield[0]} end={W.battlefield[1]} config={cfg} />}
        {inWindow(W.media) && <AsciiMediaScene progress={progress} start={W.media[0]} end={W.media[1]} config={cfg} />}
        {inWindow(W.eye) && <AsciiEyeConvergence progress={progress} start={W.eye[0]} end={W.eye[1]} pointer={pointer} />}
        {inWindow(W.wordmark) && <WordmarkFinale progress={progress} start={W.wordmark[0]} end={W.wordmark[1]} />}
      </div>

      <div className="zio-boot__scanlines" aria-hidden="true" />
      <div className="zio-boot__grain" aria-hidden="true" />

      {showSkip && (
        <button type="button" className="zio-skip" onClick={finish}>
          SKIP INTRO [ESC]
        </button>
      )}

      <BootProgressRail progress={progress} onSeek={forcePreview ? seek : undefined} />
    </div>
  );
}
