import { SR_DESCRIPTION } from "./bootConfig";
import { SysLabel } from "./BootPrimitives";
import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { useAsciiImage } from "./ascii/asciify";
import { EYE_SVG_DATA_URL } from "./ascii/eyeLogo";
import { useGridSize } from "./ascii/useGrid";

/**
 * prefers-reduced-motion state: a restrained static composition with the three
 * pillars, the asciified eye, and an Enter button. No forced 30-second animation.
 */
export function ReducedMotionStatic({ onEnter }: { onEnter: () => void }) {
  const { cols, mobile } = useGridSize();
  const eye = useAsciiImage(EYE_SVG_DATA_URL, mobile ? 44 : 70, mobile ? 20 : 26, { gain: 1.3, saturate: 1.4 });

  return (
    <div className="zio-boot" role="dialog" aria-label="ZioPSYOP intro">
      <span className="zio-corner zio-corner--tl" style={{ animation: "none", opacity: 1 }} />
      <span className="zio-corner zio-corner--tr" style={{ animation: "none", opacity: 1 }} />
      <span className="zio-corner zio-corner--bl" style={{ animation: "none", opacity: 1 }} />
      <span className="zio-corner zio-corner--br" style={{ animation: "none", opacity: 1 }} />

      <p className="sr-only">{SR_DESCRIPTION}</p>

      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 20,
          padding: 24,
          textAlign: "center",
        }}
      >
        <SysLabel style={{ letterSpacing: "0.34em", fontSize: 9, color: "var(--z-mint)" }}>
          EXPOSING & DEBUNKING ISRAEL'S ONLINE PSYOPS
        </SysLabel>

        <div style={{ position: "relative", width: mobile ? 240 : 360, height: mobile ? 120 : 150 }}>
          <AsciiField
            field={eye}
            reveal={1}
            shimmer={false}
            mode="none"
            noiseColor={PALETTE.mint}
            style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
          />
        </div>

        <SysLabel color="var(--z-text)" style={{ letterSpacing: "0.4em", fontSize: 14 }}>ZI0PSY0P</SysLabel>

        <div style={{ display: "flex", gap: 24, flexWrap: "wrap", justifyContent: "center" }}>
          <Pillar id="I" label="THE MANUFACTURED FRIEND" sub="HASBARA ASTROTURF" color="var(--z-mint)" glyph="(@)" />
          <Pillar id="II" label="THE MOST MORAL ARMY" sub="IDF CONDUCT" color="var(--z-amber)" glyph="◆" />
          <Pillar id="III" label="THE MANUFACTURED REALITY" sub="ISRAELI PR" color="var(--z-red)" glyph="▤" />
        </div>

        <SysLabel style={{ fontSize: 11, letterSpacing: "0.2em" }}>
          NARRATIVE + FORCE + FRAME = MANUFACTURED CONSENT
        </SysLabel>

        <button
          type="button"
          onClick={onEnter}
          autoFocus
          style={{
            marginTop: 4,
            padding: "10px 20px",
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: 12,
            letterSpacing: "0.24em",
            color: "var(--z-bg)",
            background: "var(--z-mint)",
            border: "none",
            cursor: "pointer",
          }}
        >
          ENTER ▶
        </button>
      </div>
    </div>
  );
}

function Pillar({
  id,
  label,
  sub,
  color,
  glyph,
}: {
  id: string;
  label: string;
  sub: string;
  color: string;
  glyph: string;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "center", maxWidth: 150 }}>
      <span style={{ color, fontSize: 20 }} aria-hidden="true">{glyph}</span>
      <SysLabel color={color} style={{ fontSize: 12, letterSpacing: "0.2em" }}>{id}</SysLabel>
      <SysLabel style={{ fontSize: 9, letterSpacing: "0.12em" }}>{label}</SysLabel>
      <SysLabel style={{ fontSize: 8, color: "var(--z-tertiary)" }}>{sub}</SysLabel>
    </div>
  );
}
