import { useMemo } from "react";
import { BootConfig, localProgress } from "./bootConfig";
import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { buildBattlefieldField } from "./ascii/sceneFields";
import { useGridSize } from "./ascii/useGrid";
import { DataRow, Question, SceneLabels, Sub, Title } from "./SceneLabels";

/** Part II — THE MOST MORAL ARMY. IDF claims measured against the documented record. */
export function AsciiBattlefieldScene({
  progress,
  start,
  end,
  config,
}: {
  progress: number;
  start: number;
  end: number;
  config: BootConfig;
}) {
  const { cols, rows } = useGridSize();
  const lp = localProgress(progress, start, end);
  const field = useMemo(() => buildBattlefieldField(cols, rows), [cols, rows]);
  const reveal = Math.min(1, lp / 0.5);

  return (
    <div className="zio-scene" data-active="true">
      <AsciiField
        field={field}
        reveal={reveal}
        mode="scan"
        noiseColor={PALETTE.amber}
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
      />
      <SceneLabels>
        <Title color="var(--z-amber)">II // THE MOST MORAL ARMY</Title>
        <Sub>BATTLEFIELD FORENSICS — IDF CONDUCT</Sub>
        <Question>THE IDF'S CLAIMED PRECISION — MEASURED AGAINST THE RECORD</Question>
        <div
          aria-hidden="true"
          style={{ display: "flex", gap: 16, fontSize: 9, letterSpacing: "0.12em", color: "var(--z-tertiary)", flexWrap: "wrap", justifyContent: "center", marginTop: 6 }}
        >
          <span><b style={{ color: "var(--z-amber)" }}>◆</b> CLAIMED/ADMITTED</span>
          <span><b style={{ color: "rgb(150,118,52)" }}>◇</b> DOCUMENTED</span>
          <span><b style={{ color: "var(--z-red)" }}>▱</b> EST./DISPUTED</span>
          <span style={{ color: "var(--z-muted)" }}>LEDGER: VIDEO / OFFICIAL / NEWS / HEALTH / OSINT</span>
        </div>
        <DataRow>
          <span>DOCUMENTED EVENTS: <b style={{ color: "var(--z-muted)" }}>{config.documentedEventCount}</b></span>
          <span>SOURCE STREAMS: <b style={{ color: "var(--z-muted)" }}>{config.sourceStreamCount}</b></span>
          <span>LAST UPDATED: <b style={{ color: "var(--z-muted)" }}>{config.lastUpdated}</b></span>
        </DataRow>
      </SceneLabels>
    </div>
  );
}
