import { CSSProperties, ReactNode } from "react";

/** Bottom-anchored label stack shared by every front scene. */
export function SceneLabels({ children }: { children: ReactNode }) {
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        bottom: "9%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 6,
        textAlign: "center",
        padding: "0 20px",
        zIndex: 3,
        pointerEvents: "none",
      }}
    >
      {children}
    </div>
  );
}

export function Title({ children, color }: { children: ReactNode; color: string }) {
  return (
    <span
      aria-hidden="true"
      style={{
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: "clamp(14px, 2.4vw, 20px)",
        letterSpacing: "0.34em",
        color,
        textShadow: `0 0 18px ${color}55`,
      }}
    >
      {children}
    </span>
  );
}

export function Sub({ children, style }: { children: ReactNode; style?: CSSProperties }) {
  return (
    <span
      className="zio-syslabel"
      aria-hidden="true"
      style={{ letterSpacing: "0.3em", ...style }}
    >
      {children}
    </span>
  );
}

export function Question({ children }: { children: ReactNode }) {
  return (
    <span
      className="zio-prose"
      aria-hidden="true"
      style={{ fontSize: "clamp(12px, 1.6vw, 15px)", marginTop: 4, color: "var(--z-text)", opacity: 0.85 }}
    >
      {children}
    </span>
  );
}

export function DataRow({ children }: { children: ReactNode }) {
  return (
    <div
      aria-hidden="true"
      style={{
        display: "flex",
        gap: 20,
        flexWrap: "wrap",
        justifyContent: "center",
        marginTop: 8,
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: 10,
        letterSpacing: "0.14em",
        color: "var(--z-tertiary)",
      }}
    >
      {children}
    </div>
  );
}
