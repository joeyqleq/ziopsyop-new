import { localProgress } from "./bootConfig";
import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { useAsciiImage } from "./ascii/asciify";
import { EYE_SVG_DATA_URL } from "./ascii/eyeLogo";
import { useGridSize } from "./ascii/useGrid";
import { SysLabel } from "./BootPrimitives";

/**
 * Signal-from-noise → ZI0PSY0P wordmark → aperture handoff.
 * Both O letters are zeroes. Brief blue/yellow RGB split (~300–500ms) settles
 * into off-white with mint edge light. The asciified eye dissolves behind it.
 */
export function WordmarkFinale({
  progress,
  start,
  end,
}: {
  progress: number;
  start: number;
  end: number;
}) {
  const { cols, mobile } = useGridSize();
  const eye = useAsciiImage(EYE_SVG_DATA_URL, cols, mobile ? 26 : 34, { gain: 1.3, saturate: 1.4 });
  const lp = localProgress(progress, start, end);

  const resolve = Math.min(1, lp / 0.4);
  const glitch = lp > 0.38 && lp < 0.5;
  const handoff = lp > 0.8;
  const eyeIntensity = Math.max(0, 0.5 - lp) * 2; // eye fades out over first 25%

  const noiseChars = "01#%@·:+/\\|[]{}";
  const target = "ZI0PSY0P";
  const rendered = target
    .split("")
    .map((ch, i) => {
      const settled = resolve > (i + 1) / target.length;
      return settled ? ch : noiseChars[(i * 7 + Math.floor(lp * 40)) % noiseChars.length];
    })
    .join("");

  return (
    <div className="zio-scene" data-active="true" style={{ flexDirection: "column", gap: 18 }}>
      {eyeIntensity > 0.01 && (
        <AsciiField
          field={eye}
          reveal={1}
          intensity={eyeIntensity}
          mode="none"
          noiseColor={PALETTE.mint}
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.5 }}
        />
      )}

      <SysLabel style={{ letterSpacing: "0.4em", opacity: resolve }}>// SIGNAL FROM NOISE</SysLabel>

      <div
        aria-hidden="true"
        style={{
          zIndex: 2,
          fontFamily: '"JetBrains Mono", monospace',
          fontSize: "clamp(38px, 9vw, 84px)",
          letterSpacing: "0.08em",
          color: resolve >= 1 ? "var(--z-text)" : "var(--z-muted)",
          textShadow: resolve >= 1 && !glitch ? "0 0 22px rgba(62,230,193,0.4)" : "none",
          animation: glitch ? "zio-rgbsplit 0.45s steps(3) 1" : "none",
        }}
      >
        {rendered}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "center", opacity: resolve, zIndex: 2 }}>
        <SysLabel color="var(--z-text)" style={{ letterSpacing: "0.24em", fontSize: 12 }}>
          THREE FRONTS. ONE EVIDENCE SYSTEM.
        </SysLabel>
        <SysLabel style={{ letterSpacing: "0.18em", fontSize: 9, color: "var(--z-tertiary)" }}>
          EXPOSING ISRAELI PSYOPS // SOURCES VISIBLE // UNCERTAINTY LABELED
        </SysLabel>
      </div>

      {handoff && (
        <SysLabel style={{ letterSpacing: "0.3em", fontSize: 10, color: "var(--z-mint)", marginTop: 4, zIndex: 2 }}>
          ENTERING CASE FILE…
        </SysLabel>
      )}
    </div>
  );
}
