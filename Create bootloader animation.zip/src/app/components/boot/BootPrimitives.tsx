import { CSSProperties } from "react";

/**
 * Progress-driven typewriter. Deterministic: the number of visible characters
 * is a function of the global timeline progress, so it pauses/scrubs correctly
 * and needs no independent timer.
 */
export function TypedText({
  text,
  progress,
  start,
  end,
  className,
  style,
  caret = false,
}: {
  text: string;
  progress: number;
  start: number;
  end: number;
  className?: string;
  style?: CSSProperties;
  caret?: boolean;
}) {
  const local = end > start ? (progress - start) / (end - start) : 1;
  const clamped = Math.max(0, Math.min(1, local));
  const shown = Math.round(clamped * text.length);
  const active = progress >= start && progress < end && shown < text.length;
  return (
    <span className={`${className ?? ""} ${caret && active ? "zio-caret" : ""}`} style={style} aria-hidden="true">
      {text.slice(0, shown)}
    </span>
  );
}

/** Uppercase, wide-tracked system label. */
export function SysLabel({
  children,
  color,
  style,
}: {
  children: React.ReactNode;
  color?: string;
  style?: CSSProperties;
}) {
  return (
    <span className="zio-syslabel" style={{ color, ...style }} aria-hidden="true">
      {children}
    </span>
  );
}

/**
 * Renders a block of ASCII art with a wipe-in reveal keyed to progress.
 * The characters themselves construct the imagery (whitespace preserved).
 */
export function AsciiBlock({
  art,
  color,
  fontSize,
  opacity = 1,
  style,
}: {
  art: string;
  color: string;
  fontSize: number;
  opacity?: number;
  style?: CSSProperties;
}) {
  return (
    <pre
      className="zio-ascii"
      aria-hidden="true"
      style={{ color, fontSize, opacity, ...style }}
    >
      {art}
    </pre>
  );
}
