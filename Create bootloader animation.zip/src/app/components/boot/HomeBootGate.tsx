import { ReactNode, useEffect, useState } from "react";
import { BootConfig } from "./bootConfig";
import { ZioBootSequence } from "./ZioBootSequence";

const SESSION_KEY = "ziopsyop-home-boot-v3";

export interface HomeBootGateProps {
  children: ReactNode;
  config?: Partial<BootConfig>;
  /**
   * Current app pathname. Pass your router's pathname for SPA route changes.
   * Falls back to window.location.pathname (+ popstate) when omitted.
   */
  pathname?: string;
  /** Preview/dev only: force the sequence to run and ignore the session guard. */
  forcePreview?: boolean;
}

function safeSessionGet(key: string): boolean {
  try {
    return window.sessionStorage.getItem(key) === "done";
  } catch {
    return false;
  }
}
function safeSessionSet(key: string) {
  try {
    window.sessionStorage.setItem(key, "done");
  } catch {
    /* storage unavailable — degrade gracefully */
  }
}

/**
 * Gates the boot sequence:
 * - Runs only when the pathname is exactly "/".
 * - Once per browser-tab session (sessionStorage), unless forcePreview.
 * - Deep-linking elsewhere first does NOT arm the boot; entering "/" later does.
 * - The real homepage renders behind the fixed overlay the whole time.
 * - If the sequence throws during init, entry is allowed rather than blocked.
 */
export function HomeBootGate({ children, config, pathname, forcePreview = false }: HomeBootGateProps) {
  const [path, setPath] = useState(() => pathname ?? (typeof window !== "undefined" ? window.location.pathname : "/"));

  useEffect(() => {
    if (pathname != null) {
      setPath(pathname);
      return;
    }
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [pathname]);

  const isHome = path === "/";

  const [show, setShow] = useState(false);

  useEffect(() => {
    if (forcePreview) {
      setShow(true);
      return;
    }
    // Arm only when actually on the homepage and not yet completed this session.
    if (isHome && !safeSessionGet(SESSION_KEY)) {
      setShow(true);
    }
  }, [isHome, forcePreview]);

  const handleComplete = () => {
    if (!forcePreview) safeSessionSet(SESSION_KEY);
    setShow(false);
  };

  return (
    <>
      {children}
      {show && (isHome || forcePreview) && (
        <BootErrorBoundary onFail={handleComplete}>
          <ZioBootSequence config={config} onComplete={handleComplete} forcePreview={forcePreview} />
        </BootErrorBoundary>
      )}
    </>
  );
}

/** If anything in the sequence throws, dismiss the overlay so the site is usable. */
import { Component, ErrorInfo } from "react";
class BootErrorBoundary extends Component<{ children: ReactNode; onFail: () => void }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(_e: Error, _info: ErrorInfo) {
    this.props.onFail();
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}
