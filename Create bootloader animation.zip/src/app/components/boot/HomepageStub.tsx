import { AsciiField } from "./ascii/AsciiField";
import { PALETTE } from "./ascii/asciiCore";
import { useAsciiImage } from "./ascii/asciify";
import { EYE_SVG_DATA_URL } from "./ascii/eyeLogo";

/**
 * Minimal stand-in for the EXISTING ZioPSYOP homepage — used only so the preview
 * has something for the boot overlay to dissolve into. In production you render
 * your real homepage here; the boot component does not recreate it.
 */
export function HomepageStub() {
  // Renders the eye via the asciified data-URL (the previous <img> bundler URL
  // rendered as a broken image; the data-URL approach is robust).
  const eye = useAsciiImage(EYE_SVG_DATA_URL, 90, 32, { gain: 1.3, saturate: 1.4 });

  return (
    <div
      style={{
        minHeight: "100%",
        height: "100%",
        background: "#060608",
        color: "#e8eae9",
        fontFamily: '"JetBrains Mono", monospace',
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 20,
        padding: 24,
        textAlign: "center",
      }}
    >
      <div style={{ position: "relative", width: "min(520px, 80%)", height: 180 }}>
        <AsciiField
          field={eye}
          reveal={1}
          shimmer
          mode="none"
          noiseColor={PALETTE.mint}
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
        />
      </div>
      <h1 style={{ fontFamily: '"JetBrains Mono", monospace', letterSpacing: "0.14em", margin: 0 }}>ZI0PSY0P</h1>
      <p style={{ fontFamily: '"Space Grotesk", sans-serif', color: "#8a8f98", maxWidth: 460, margin: 0 }}>
        Open-source forensics exposing and debunking the most widespread Israeli / IDF psyops online.
        The real homepage renders here, behind the boot overlay, so its assets load during the sequence
        and the aperture reveals it seamlessly.
      </p>
    </div>
  );
}
