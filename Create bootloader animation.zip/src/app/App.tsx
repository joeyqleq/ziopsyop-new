import { useState } from "react";
import { HomeBootGate } from "./components/boot/HomeBootGate";
import { HomepageStub } from "./components/boot/HomepageStub";

/**
 * ISOLATED PREVIEW HARNESS for the ZioPSYOP boot-opening component.
 * This page is not the production homepage — it demonstrates the boot sequence
 * in desktop and mobile framings with a replay/debug control.
 *
 * ── INTEGRATION NOTE ─────────────────────────────────────────────────────────
 * On the real site, wrap ONLY the homepage route with <HomeBootGate>:
 *
 *   // e.g. in your root layout / route element for "/"
 *   import { HomeBootGate } from "@/components/boot/HomeBootGate";
 *
 *   <HomeBootGate pathname={location.pathname}>
 *     <HomePage />
 *   </HomeBootGate>
 *
 * HomeBootGate runs the sequence only when pathname === "/", once per tab
 * session (sessionStorage key "ziopsyop-home-boot-v3"). Pass your router's
 * pathname so SPA route changes are detected; omit it to fall back to
 * window.location.pathname + popstate. Do NOT wrap /part-i, /forensics, etc.
 * ─────────────────────────────────────────────────────────────────────────────
 */
export default function App() {
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const [replayKey, setReplayKey] = useState(0);

  const frame =
    device === "desktop"
      ? { width: "100%", maxWidth: 1100, aspectRatio: "16 / 9" }
      : { width: 360, height: 720, maxWidth: "100%" };

  return (
    <div style={{ minHeight: "100vh", background: "#0d0d12", color: "#e8eae9", fontFamily: '"JetBrains Mono", monospace' }}>
      {/* debug controls — PREVIEW/DEV ONLY */}
      <div
        style={{
          display: "flex",
          gap: 10,
          alignItems: "center",
          flexWrap: "wrap",
          padding: "14px 18px",
          borderBottom: "1px solid rgba(232,234,233,0.1)",
        }}
      >
        <span style={{ fontSize: 11, letterSpacing: "0.2em", color: "#8a8f98" }}>ZIOPSYOP BOOT // PREVIEW</span>
        <div style={{ flex: 1 }} />
        <DebugButton active={device === "desktop"} onClick={() => setDevice("desktop")}>DESKTOP</DebugButton>
        <DebugButton active={device === "mobile"} onClick={() => setDevice("mobile")}>MOBILE</DebugButton>
        <DebugButton onClick={() => setReplayKey((k) => k + 1)}>↻ REPLAY</DebugButton>
      </div>

      <div style={{ display: "flex", justifyContent: "center", padding: 24 }}>
        {/* The gate + overlay are constrained to this device frame in preview.
            (In production the overlay is position:fixed over the full viewport.) */}
        <div
          style={{
            ...frame,
            position: "relative",
            overflow: "hidden",
            border: "1px solid rgba(232,234,233,0.14)",
            contain: "layout paint size",
          }}
        >
          <HomeBootGate key={replayKey} forcePreview>
            <HomepageStub />
          </HomeBootGate>
        </div>
      </div>

      <p style={{ maxWidth: 720, margin: "0 auto 40px", padding: "0 24px", fontSize: 12, color: "#565b64", fontFamily: '"Space Grotesk", sans-serif' }}>
        Reduced-motion: enable your OS "reduce motion" setting and press REPLAY to see the restrained
        static state (three pillars, the eye, and an Enter button). Skip via the SKIP control, Esc, Enter,
        or Space. Evidence values are configurable props and default to "UNAVAILABLE" so nothing is faked.
      </p>
    </div>
  );
}

function DebugButton({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        padding: "6px 12px",
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: 10,
        letterSpacing: "0.16em",
        color: active ? "#060608" : "#8a8f98",
        background: active ? "#3ee6c1" : "transparent",
        border: "1px solid rgba(62,230,193,0.4)",
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}
